OrderDesk — Hostinger Ready Upload Package
=========================================

Upload & Run (Zero npm install needed):
1. Open Hostinger hPanel -> Files -> File Manager -> public_html
2. Upload this ZIP file and click "Extract" directly inside public_html
   (Make sure index.html, api.php, .htaccess, assets/, and data/ are inside public_html)
3. Open your website domain in Chrome/Mobile — OrderDesk works immediately!

Where does data get saved?
- By default, ALL orders, customers, cities, cleaners, and accounts save automatically
  inside: data/portal-db.json (no MySQL setup required).
- Want Hostinger MySQL database too?
  a) Open Hostinger hPanel -> Databases -> phpMyAdmin -> Import -> select "database.sql" from this ZIP.
  b) Edit config.php and fill ORDERDESK_MYSQL_NAME, ORDERDESK_MYSQL_USER, ORDERDESK_MYSQL_PASS
     (OR enter them in Admin Panel -> Hostinger Sync -> Hostinger MySQL).
  Once filled, every order automatically saves to BOTH data/portal-db.json and MySQL!

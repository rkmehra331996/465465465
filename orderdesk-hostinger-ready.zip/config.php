<?php
// Optional Configuration for Hostinger Hosting
// 1) Optional: Add Gemini API Key if you want Hindi/Punjabi auto-translation on Hostinger
define('ORDERDESK_GEMINI_API_KEY', '');

// 2) Optional: Also mirror orders to Hostinger MySQL (leave empty to use data/portal-db.json only)
define('ORDERDESK_MYSQL_HOST', 'localhost');
define('ORDERDESK_MYSQL_NAME', '');
define('ORDERDESK_MYSQL_USER', '');
define('ORDERDESK_MYSQL_PASS', '');
